package com.huellitas.huellitas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HuellitasApplication {

	public static void main(String[] args) {
		SpringApplication.run(HuellitasApplication.class, args);
	}

}
