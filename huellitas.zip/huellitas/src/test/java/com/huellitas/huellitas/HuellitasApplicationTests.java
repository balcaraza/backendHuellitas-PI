package com.huellitas.huellitas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HuellitasApplicationTests {

	@Test
	void contextLoads() {
	}

}
